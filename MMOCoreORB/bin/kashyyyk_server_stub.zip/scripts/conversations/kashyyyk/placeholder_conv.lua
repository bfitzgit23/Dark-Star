-- Placeholder conversation handler for Kashyyyk
local ObjectManager = require("managers.object.object_manager")

KashyyykPlaceholderConvoHandler = Object:new {
    tstring = "Hello traveler, this conversation is a placeholder."
}
