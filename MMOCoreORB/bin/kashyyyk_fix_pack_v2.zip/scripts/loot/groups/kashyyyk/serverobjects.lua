-- Kashyyyk Loot Groups

includeFile("kashyyyk/kashyyyk_common.lua")
includeFile("kashyyyk/kashyyyk_rare.lua")
