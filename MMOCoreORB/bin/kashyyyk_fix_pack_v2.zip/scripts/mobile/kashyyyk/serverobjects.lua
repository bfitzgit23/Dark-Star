-- Kashyyyk Mobiles

includeFile("kashyyyk/kashyyyk_bandit.lua")
includeFile("kashyyyk/kashyyyk_stalker.lua")
includeFile("kashyyyk/myyydril_warrior.lua")
includeFile("kashyyyk/katarn.lua")
includeFile("kashyyyk/kk_guide_npc.lua")
includeFile("kashyyyk/kk_theme_scout.lua")
includeFile("kashyyyk/kk_theme_warden.lua")
includeFile("kashyyyk/kk_theme_chief.lua")
