# Kashyyyk Fix Pack (Core3)

This pack fixes the Kashyyyk load errors by ensuring all mobiles, loot groups, and conversations are properly included.

## Installation

1. **Backup your server scripts folder** first.

2. Copy the contents of this zip into your Core3 `scripts/` directory.
   - Path structure will look like:
     ```
     scripts/
       mobile/kashyyyk/serverobjects.lua
       loot/groups/kashyyyk/serverobjects.lua
       conversations/kashyyyk/...
       screenplays/kashyyyk/...
     ```

3. Open your **global serverobjects.lua** (found in `scripts/` root).  
   Make sure it includes these lines:
   ```lua
   includeFile("mobile/kashyyyk/serverobjects.lua")
   includeFile("loot/groups/kashyyyk/serverobjects.lua")
   includeFile("conversations/kashyyyk/serverobjects.lua")
   includeFile("screenplays/kashyyyk/serverobjects.lua")
   ```

4. Recompile/restart your Core3 server. Kashyyyk should now boot without screenplay/mobile errors.

## Notes

- All Kashyyyk mobiles (`kk_theme_chief`, `kk_theme_warden`, etc.) are now registered correctly.
- Loot groups are included properly.
- Conversation handlers are untouched (they are valid as-is).

If you still get errors, check your `log/core3.log` for missing `.iff` files in templates or typos in spawn points.


---

### Global serverobjects.lua (Full Example)

Make sure your root `scripts/serverobjects.lua` contains these lines:

```lua
-- Kashyyyk Content
includeFile("mobile/kashyyyk/serverobjects.lua")
includeFile("loot/groups/kashyyyk/serverobjects.lua")
includeFile("conversations/kashyyyk/serverobjects.lua")
includeFile("screenplays/kashyyyk/serverobjects.lua")
```

## Added in this pack
- conversations/kashyyyk/serverobjects.lua (auto-generated to include all conversation + handler files)
- screenplays/kashyyyk/serverobjects.lua (auto-generated to include all Kashyyyk screenplay files)
